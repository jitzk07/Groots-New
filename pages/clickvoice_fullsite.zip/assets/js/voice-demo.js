const startBtn = document.getElementById('startRecord');
const stopBtn = document.getElementById('stopRecord');
const playback = document.getElementById('playback');
let mediaRecorder, audioChunks = [];

if (startBtn) {
  startBtn.onclick = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    mediaRecorder = new MediaRecorder(stream);
    audioChunks = [];
    mediaRecorder.ondataavailable = e => audioChunks.push(e.data);
    mediaRecorder.onstop = () => {
      const blob = new Blob(audioChunks, { type: 'audio/wav' });
      playback.src = URL.createObjectURL(blob);
    };
    mediaRecorder.start();
  };
}
if (stopBtn) {
  stopBtn.onclick = () => {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') mediaRecorder.stop();
  };
}