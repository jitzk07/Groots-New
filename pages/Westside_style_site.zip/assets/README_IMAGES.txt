PLACEHOLDER IMAGE
Replace this file with actual images. Suggested filenames to replace:
- assets/hero.jpg
- assets/banner-1.jpg
- assets/product-1.jpg ... product-12.jpg
- assets/placeholder-1.jpg, placeholder-2.jpg
