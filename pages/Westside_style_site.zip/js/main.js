// main.js - basic interactivity
document.addEventListener('DOMContentLoaded', function(){
  // Mobile menu toggle (if exists)
  const menuBtn = document.getElementById('menu-btn');
  const nav = document.getElementById('main-nav');
  if(menuBtn && nav){
    menuBtn.addEventListener('click', ()=>{
      nav.classList.toggle('open');
    });
  }

  // Product quick-view modal
  document.querySelectorAll('[data-quickview]').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      e.preventDefault();
      const id = btn.getAttribute('data-quickview');
      const modal = document.getElementById('quickview-modal');
      if(modal){
        // load info from data attributes
        modal.querySelector('.qv-title').textContent = btn.getAttribute('data-title') || 'Product';
        modal.querySelector('.qv-price').textContent = btn.getAttribute('data-price') || 'Price';
        const img = modal.querySelector('img');
        img.src = btn.getAttribute('data-img') || 'assets/placeholder-1.jpg';
        modal.style.display = 'block';
      }
    });
  });

  // Close modal
  const qvClose = document.getElementById('qv-close');
  if(qvClose){
    qvClose.addEventListener('click', ()=>{
      document.getElementById('quickview-modal').style.display = 'none';
    });
  }
});