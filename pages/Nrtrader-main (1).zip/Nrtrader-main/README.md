# MSquare - Premium Utensils & Disposables E-commerce Website

A comprehensive e-commerce website for disposable products and steel/copper utensils with three user roles: Admin, Reseller, and Customer.

## 🚀 Features

### 🌟 Main Features
- **Three User Roles**: Admin, Reseller, and Customer with different access levels
- **Product Categories**: Disposable Products, Steel Utensils, Copper Utensils
- **Shopping Cart & Checkout**: Full e-commerce functionality
- **Responsive Design**: Mobile-first approach with modern UI/UX
- **User Authentication**: Login/Register system with role-based access
- **Product Management**: Admin can add, edit, and delete products
- **Order Management**: Track orders and update status
- **Wholesale Pricing**: Special pricing for resellers

### 👨‍💼 Admin Dashboard
- Product management (add, edit, delete)
- Order management and status updates
- User management
- Analytics and reporting
- Revenue tracking

### 🏪 Reseller Dashboard
- Wholesale pricing (20-30% discounts)
- Bulk order calculator
- Quick order functionality
- Order history
- Resource downloads (catalogs, images, price lists)
- Dedicated support contact

### 🛒 Customer Features
- Browse products by category
- Search functionality
- Shopping cart
- User registration and login
- Order history
- Best sellers section

## 📁 Project Structure

```
nrTrader/
├── index.html                 # Homepage
├── css/
│   └── style.css             # Main stylesheet
├── js/
│   └── main.js               # Main JavaScript functionality
├── pages/
│   ├── disposable.html       # Disposable products page
│   ├── steel.html            # Steel utensils page
│   ├── copper.html           # Copper utensils page
│   ├── bestsellers.html      # Best sellers page
│   ├── cart.html             # Shopping cart page
│   ├── admin-dashboard.html  # Admin dashboard
│   └── reseller-dashboard.html # Reseller dashboard
├── images/
│   └── products/             # Product images directory
└── README.md                 # Project documentation
```

## 🛠️ Technologies Used

- **HTML5**: Semantic markup
- **CSS3**: Modern styling with Flexbox and Grid
- **JavaScript (ES6+)**: Dynamic functionality
- **Font Awesome**: Icons
- **Google Fonts**: Typography (Inter font family)
- **Local Storage**: Data persistence

## 🎨 Design Features

### Color Scheme
- Primary: `#667eea` (Blue gradient)
- Secondary: `#764ba2` (Purple gradient)
- Success: `#28a745` (Green)
- Warning: `#f39c12` (Orange)
- Danger: `#e74c3c` (Red)
- Copper: `#b8860b` (Gold/Copper)

### UI Components
- Modern card-based layout
- Gradient backgrounds
- Smooth animations and transitions
- Responsive grid system
- Interactive buttons and forms
- Modal dialogs for authentication

## 🚀 Getting Started

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Local web server (optional, for development)

### Installation
1. Clone or download the project files
2. Open `index.html` in your web browser
3. For development, use a local server:
   ```bash
   # Using Python
   python -m http.server 8000
   
   # Using Node.js
   npx http-server
   
   # Using PHP
   php -S localhost:8000
   ```

## 👥 User Roles & Access

### 🔑 Admin Access
- **Default Admin Account**: 
  - Email: `admin@nrtrader.com`
  - Password: `admin123`
- **Access**: Full system control, product management, user management

### 🏪 Reseller Access
- **Default Reseller Account**:
  - Email: `reseller@nrtrader.com`
  - Password: `reseller123`
- **Access**: Wholesale pricing, bulk orders, dedicated support

### 👤 Customer Access
- **Default Customer Account**:
  - Email: `customer@nrtrader.com`
  - Password: `customer123`
- **Access**: Shopping, orders, regular pricing

## 📦 Product Categories

### 🥤 Disposable Products
- Eco-friendly paper plates
- Biodegradable plastic cups
- Areca leaf plates
- Disposable cutlery sets
- Paper straws
- Food containers

### 🔧 Steel Utensils
- Premium steel thali sets
- Steel glasses and tumblers
- Steel cookware
- Storage containers
- Steel bowls (katori sets)

### 🥉 Copper Utensils
- Copper water bottles
- Copper glasses and tumblers
- Copper thali sets
- Copper serving bowls
- Copper jugs

## 🛒 E-commerce Features

### Shopping Cart
- Add/remove products
- Quantity adjustment
- Price calculation
- Persistent storage

### Checkout Process
- User authentication required
- Order summary
- Total calculation with shipping
- Order confirmation

### Order Management
- Order tracking
- Status updates (pending, processing, shipped, delivered)
- Order history

## 🎯 Key Functionalities

### Search & Filter
- Product search by name
- Category filtering
- Price range filtering
- Sorting options

### User Management
- Registration with role selection
- Login/logout functionality
- Profile management
- Role-based access control

### Admin Features
- Product CRUD operations
- User role management
- Order status updates
- Analytics dashboard

### Reseller Features
- Wholesale pricing calculator
- Bulk order management
- Quick order functionality
- Resource downloads

## 🔧 Customization

### Adding New Products
1. Login as admin
2. Go to Admin Dashboard
3. Use "Add Product" form
4. Fill in product details
5. Save product

### Modifying Styles
- Edit `css/style.css`
- Customize color variables
- Adjust layout components
- Update responsive breakpoints

### Adding New Features
- Extend `js/main.js`
- Add new HTML pages
- Update navigation menus
- Implement new user roles if needed

## 📱 Responsive Design

The website is fully responsive and works on:
- Desktop (1200px+)
- Tablet (768px - 1199px)
- Mobile (320px - 767px)

### Mobile Features
- Touch-friendly navigation
- Optimized product grids
- Collapsible menus
- Swipe-friendly interactions

## 🚀 Future Enhancements

### Planned Features
- Payment gateway integration
- Email notifications
- Advanced search filters
- Product reviews and ratings
- Inventory management
- Multi-language support
- SEO optimization
- Progressive Web App (PWA)

### Backend Integration
- Database connectivity
- User authentication API
- Payment processing
- Order management system
- Inventory tracking
- Analytics reporting

## 🐛 Troubleshooting

### Common Issues
1. **Images not loading**: Check image paths and ensure images exist
2. **JavaScript errors**: Check browser console for errors
3. **Styling issues**: Clear browser cache
4. **Local storage issues**: Check if local storage is enabled

### Browser Compatibility
- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## 📄 License

This project is created for demonstration purposes. Feel free to use and modify as needed.

## 🤝 Contributing

1. Fork the project
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## 📞 Support

For support and questions:
- Email: Msincupvtltd095@gmail.com
- Phone: 7982293095
- Address: Village. Gijhor sector 53 near shine foundation school, Noida, UP 201301

---

**MSquare** - Your trusted partner for premium disposable and steel utensils! 🏆
