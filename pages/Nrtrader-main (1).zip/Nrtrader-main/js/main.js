// Global variables
let currentUser = null;
let cart = JSON.parse(localStorage.getItem('cart')) || [];
let products = [];
let orders = JSON.parse(localStorage.getItem('orders')) || [];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    loadProducts();
    initializeDefaultUsers();
    updateCartDisplay();
    loadBestSellers();
    setupEventListeners();
    
    // Check if user is logged in
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
        updateAuthDisplay();
    }
});

// Load products data
function loadProducts() {
    products = [
        // Disposable Products
        {
            id: 1,
            name: "Eco-Friendly Paper Plates (Pack of 50)",
            price: 299,
            category: "disposable",
            image: "/images/disposable-plate.webp",
            description: "Biodegradable paper plates perfect for parties and events",
            rating: 4.5,
            reviews: 128,
            stock: 100
        },
        {
            id: 2,
            name: "Biodegradable Plastic Cups (Pack of 25)",
            price: 199,
            category: "disposable",
            image: "/images/plastic-cups.jpg",
            description: "Environmentally friendly plastic cups",
            rating: 4.3,
            reviews: 89,
            stock: 150
        },
        {
            id: 3,
            name: "Areca Leaf Plates (Pack of 100)",
            price: 599,
            category: "disposable",
            image: "/images/areca-leaf-plates.jpg",
            description: "Natural areca leaf plates, completely biodegradable",
            rating: 4.7,
            reviews: 67,
            stock: 80
        },
        {
            id: 4,
            name: "Disposable Cutlery Set",
            price: 149,
            category: "disposable",
            image: "/images/disposable-cutlery-set.webp",
            description: "Complete set of spoons, forks, and knives",
            rating: 4.2,
            reviews: 156,
            stock: 200
        },
        {
            id: 5,
            name: "Paper Straws (Pack of 200)",
            price: 179,
            category: "disposable",
            image: "/images/paper-straws.jpg",
            description: "Eco-friendly paper straws in various colors",
            rating: 4.4,
            reviews: 94,
            stock: 120
        },
        {
            id: 6,
            name: "Food Containers (Pack of 10)",
            price: 399,
            category: "disposable",
            image: "/images/disposable-container-set.jpg",
            description: "Microwave-safe disposable food containers",
            rating: 4.1,
            reviews: 78,
            stock: 90
        },

        // Steel Utensils
        {
            id: 7,
            name: "Premium Steel Thali Set",
            price: 1299,
            category: "steel",
            image: "/images/steel-thali-set.jpg",
            description: "High-quality stainless steel thali set",
            rating: 4.6,
            reviews: 203,
            stock: 50
        },
        {
            id: 8,
            name: "Steel Glasses Set (6 Pieces)",
            price: 799,
            category: "steel",
            image: "/images/steel-glass-set.jpg",
            description: "Durable stainless steel drinking glasses",
            rating: 4.5,
            reviews: 167,
            stock: 75
        },
        {
            id: 9,
            name: "Steel Cookware Set",
            price: 2499,
            category: "steel",
            image: "/images/steel-cookware-set.webp",
            description: "Complete steel cookware set with kadahi and saucepan",
            rating: 4.7,
            reviews: 134,
            stock: 30
        },
        {
            id: 10,
            name: "Steel Storage Containers (Set of 5)",
            price: 899,
            category: "steel",
            image: "images/products/steel-containers.jpg",
            image: "/images/Steel Storage Container (Set of 5).jpg",
            description: "Airtight steel storage containers",
            rating: 4.4,
            reviews: 89,
            stock: 60
        },
        {
            id: 11,
            name: "Steel Bowls Set (Katori - 8 Pieces)",
            price: 599,
            category: "steel",
            image: "images/products/steel-bowls.jpg",
            image: "/images/Steel bowl set katori .jpg",
            description: "Traditional steel katori set for serving",
            rating: 4.3,
            reviews: 112,
            stock: 85
        },

        // Copper Utensils
        {
            id: 12,
            name: "Copper Water Bottle",
            price: 1599,
            category: "copper",
            image: "/images/copper-water-bottle.webp",
            description: "Pure copper water bottle with health benefits",
            rating: 4.8,
            reviews: 245,
            stock: 40
        },
        {
            id: 13,
            name: "Copper Glasses Set (4 Pieces)",
            price: 1199,
            category: "copper",
            image: "images/products/copper-glasses.jpg",
            image: "/images/Copper Glasses Set (4 Pieces).jpg",
            description: "Premium copper drinking glasses",
            rating: 4.6,
            reviews: 178,
            stock: 35
        },
        {
            id: 14,
            name: "Copper Thali Set",
            price: 1899,
            category: "copper",
            image: "images/products/copper-thali.jpg",
            image: "/images/Copper thali set.jpg",
            description: "Traditional copper thali set for special occasions",
            rating: 4.7,
            reviews: 156,
            stock: 25
        },
        {
            id: 15,
            name: "Copper Serving Bowls (Set of 3)",
            price: 1399,
            category: "copper",
            image: "images/products/copper-bowls.jpg",
            image: "/images/copper serving bowls(set of 3).jpg",
            description: "Elegant copper serving bowls",
            rating: 4.5,
            reviews: 98,
            stock: 45
        },
        {
            id: 16,
            name: "Copper Jug (2 Liter)",
            price: 999,
            category: "copper",
            image: "images/products/copper-jug.jpg",
            image: "/images/Copper jug 2litre.jpeg",
            description: "Traditional copper water jug",
            rating: 4.4,
            reviews: 134,
            stock: 55
        }
    ];
    
    localStorage.setItem('products', JSON.stringify(products));
}

// Load best sellers
function loadBestSellers() {
    const bestSellersGrid = document.getElementById('bestSellersGrid');
    if (!bestSellersGrid) return;
    
    const bestSellers = products.filter(product => product.rating >= 4.5).slice(0, 4);
    
    bestSellersGrid.innerHTML = bestSellers.map(product => `
        <div class="product-card">
            <div class="product-image">
                <img src="${product.image}" alt="${product.name}" onerror="this.src='/images/placeholder.jpg'">
                <div class="product-badge">Best Seller</div>
            </div>
            <div class="product-info">
                <h3 class="product-title"><a href="pages/product-detail.html?id=${product.id}" class="product-link">${product.name}</a></h3>
                <div class="product-price">₹${product.price}</div>
                <div class="product-rating">
                    <div class="stars">${generateStars(product.rating)}</div>
                    <span class="rating-text">(${product.reviews} reviews)</span>
                </div>
                <div class="product-actions">
                    <button class="add-to-cart" onclick="addToCartWithLoading(${product.id})">Add to Cart</button>
                    <button class="wishlist-btn" onclick="addToWishlist(${product.id})" title="Add to Wishlist">
                        <i class="fas fa-heart"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// Generate star rating HTML
function generateStars(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    let starsHTML = '';
    
    for (let i = 0; i < fullStars; i++) {
        starsHTML += '<i class="fas fa-star"></i>';
    }
    
    if (hasHalfStar) {
        starsHTML += '<i class="fas fa-star-half-alt"></i>';
    }
    
    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
        starsHTML += '<i class="far fa-star"></i>';
    }
    
    return starsHTML;
}

// Setup event listeners
function setupEventListeners() {
    // Search functionality
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('keypress', handleSearch);
    }
    
    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Register form
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
    
    // Mobile menu toggle
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', () => {
            navMenu.classList.toggle('active');
        });
    }
}

// Handle search
function handleSearch(e) {
    if (e.key === 'Enter') {
        const query = e.target.value.trim();
        if (query) {
            // Redirect to search page
            window.location.href = `pages/search.html?q=${encodeURIComponent(query)}`;
        }
    }
}

// Handle login
function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    // Simple authentication (in real app, this would be server-side)
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const user = users.find(u => u.email === email && u.password === password);
    
    if (user) {
        currentUser = user;
        localStorage.setItem('currentUser', JSON.stringify(user));
        updateAuthDisplay();
        closeLoginModal();
        showMessage('Login successful!', 'success');
        
        // Redirect based on user role
        if (user.role === 'admin') {
            window.location.href = 'pages/admin-dashboard.html';
        } else if (user.role === 'reseller') {
            window.location.href = 'pages/reseller-dashboard.html';
        }
    } else {
        showMessage('Invalid email or password', 'error');
    }
}

// Handle registration
function handleRegister(e) {
    e.preventDefault();
    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    const role = document.getElementById('registerRole').value;
    
    const users = JSON.parse(localStorage.getItem('users')) || [];
    
    // Check if user already exists
    if (users.find(u => u.email === email)) {
        showMessage('User already exists with this email', 'error');
        return;
    }
    
    const newUser = {
        id: Date.now(),
        name,
        email,
        password,
        role,
        createdAt: new Date().toISOString()
    };
    
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    
    showMessage('Registration successful! Please login.', 'success');
    closeRegisterModal();
    openLoginModal();
}

// Update authentication display
function updateAuthDisplay() {
    const authButtons = document.querySelector('.auth-buttons');
    const userAccountBtn = document.getElementById('userAccountBtn');
    if (!authButtons) return;
    
    if (currentUser) {
        authButtons.innerHTML = `
            <span class="user-welcome">Welcome, ${currentUser.name}</span>
            <button class="btn btn-outline" onclick="logout()">Logout</button>
        `;
        if (userAccountBtn) {
            userAccountBtn.style.display = 'flex';
        }
    } else {
        authButtons.innerHTML = `
            <button class="btn btn-outline" onclick="openLoginModal()">Login</button>
            <button class="btn btn-primary" onclick="openRegisterModal()">Register</button>
        `;
        if (userAccountBtn) {
            userAccountBtn.style.display = 'none';
        }
    }
}

// Logout function
function logout() {
    currentUser = null;
    localStorage.removeItem('currentUser');
    updateAuthDisplay();
    showMessage('Logged out successfully', 'success');
}

// Modal functions
function openLoginModal() {
    document.getElementById('loginModal').style.display = 'block';
}

function closeLoginModal() {
    document.getElementById('loginModal').style.display = 'none';
}

function openRegisterModal() {
    document.getElementById('registerModal').style.display = 'block';
}

function closeRegisterModal() {
    document.getElementById('registerModal').style.display = 'none';
}

// Close modals when clicking outside
window.onclick = function(event) {
    const loginModal = document.getElementById('loginModal');
    const registerModal = document.getElementById('registerModal');
    
    if (event.target === loginModal) {
        loginModal.style.display = 'none';
    }
    if (event.target === registerModal) {
        registerModal.style.display = 'none';
    }
}

// Cart functions
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    const existingItem = cart.find(item => item.id === productId);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            image: product.image,
            quantity: 1
        });
    }
    
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartDisplay();
    showMessage('Product added to cart!', 'success');
}

function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartDisplay();
    showMessage('Product removed from cart', 'success');
}

function updateCartQuantity(productId, newQuantity) {
    if (newQuantity <= 0) {
        removeFromCart(productId);
        return;
    }
    
    const item = cart.find(item => item.id === productId);
    if (item) {
        item.quantity = newQuantity;
        localStorage.setItem('cart', JSON.stringify(cart));
        updateCartDisplay();
    }
}

function updateCartDisplay() {
    const cartCount = document.querySelector('.cart-count');
    if (cartCount) {
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        cartCount.textContent = totalItems;
    }
    
    // Update cart page if we're on it
    if (window.location.pathname.includes('cart.html')) {
        loadCartPage();
    }
}

// Enhanced cart page loading with professional UI
function loadCartPage() {
    const cartItemsContainer = document.getElementById('cartItems');
    const emptyCartDiv = document.getElementById('emptyCart');
    const cartContent = document.querySelector('.cart-content');
    
    if (!cartItemsContainer) return;
    
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '';
        if (emptyCartDiv) emptyCartDiv.style.display = 'block';
        if (cartContent) cartContent.style.display = 'none';
        updateCartTotal();
        return;
    }
    
    if (emptyCartDiv) emptyCartDiv.style.display = 'none';
    if (cartContent) cartContent.style.display = 'grid';
    
    cartItemsContainer.innerHTML = cart.map(item => `
        <div class="cart-item">
            <div class="cart-item-image">
                <img src="${item.image}" alt="${item.name}" onerror="this.src='/images/placeholder.jpg'">
            </div>
            <div class="cart-item-info">
                <h3>${item.name}</h3>
                <p class="cart-item-price">₹${item.price}</p>
                <div class="cart-item-quantity">
                    <button class="quantity-btn" onclick="updateCartQuantity(${item.id}, ${item.quantity - 1})">-</button>
                    <input type="number" class="quantity-input" value="${item.quantity}" min="1" onchange="updateQuantityFromInput(${item.id}, this.value)">
                    <button class="quantity-btn" onclick="updateCartQuantity(${item.id}, ${item.quantity + 1})">+</button>
                </div>
            </div>
            <div class="cart-item-actions">
                <button class="remove-item" onclick="removeFromCart(${item.id})" title="Remove item">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
    
    updateCartTotal();
    updateItemCount();
}

// Update quantity from input field
function updateQuantityFromInput(productId, newQuantity) {
    const quantity = parseInt(newQuantity);
    if (quantity < 1) {
        removeFromCart(productId);
        return;
    }
    updateCartQuantity(productId, quantity);
}

// Update item count display
function updateItemCount() {
    const itemCountElement = document.getElementById('itemCount');
    if (itemCountElement) {
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        itemCountElement.textContent = `${totalItems} item${totalItems !== 1 ? 's' : ''}`;
    }
}

// Enhanced cart total calculation and display
function updateCartTotal() {
    const subtotalElement = document.getElementById('subtotal');
    const taxElement = document.getElementById('tax');
    const totalElement = document.getElementById('total');
    const checkoutBtn = document.getElementById('checkoutBtn');
    
    if (!subtotalElement || !totalElement) return;
    
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const shipping = subtotal > 500 ? 0 : 50;
    const tax = Math.round(subtotal * 0.18); // 18% GST
    const total = subtotal + shipping + tax;
    
    subtotalElement.textContent = `₹${subtotal}`;
    taxElement.textContent = `₹${tax}`;
    totalElement.textContent = `₹${total}`;
    
    // Update shipping display
    const shippingElement = document.getElementById('shipping');
    if (shippingElement) {
        shippingElement.textContent = shipping === 0 ? 'Free' : `₹${shipping}`;
    }
    
    // Update checkout button state
    if (checkoutBtn) {
        checkoutBtn.disabled = cart.length === 0;
        checkoutBtn.style.opacity = cart.length === 0 ? '0.6' : '1';
    }
}

// Enhanced checkout function for cart page
function proceedToCheckout() {
    if (!currentUser) {
        showMessage('Please login to proceed with checkout', 'error');
        openLoginModal();
        return;
    }
    
    if (cart.length === 0) {
        showMessage('Your cart is empty. Add some products to checkout.', 'error');
        return;
    }
    
    // Create order
    const order = {
        id: Date.now(),
        userId: currentUser.id,
        items: [...cart],
        total: cart.reduce((sum, item) => sum + (item.price * item.quantity), 0),
        date: new Date().toISOString(),
        status: 'pending'
    };
    
    // Save order to localStorage
    const orders = JSON.parse(localStorage.getItem('orders') || '[]');
    orders.push(order);
    localStorage.setItem('orders', JSON.stringify(orders));
    
    // Clear cart
    cart = [];
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Show success message
    showMessage('Order placed successfully! Redirecting to confirmation...', 'success');
    
    // Redirect to order confirmation
    setTimeout(() => {
        window.location.href = `order-confirmation.html?id=${order.id}`;
    }, 2000);
}

function checkout() {
    if (!currentUser) {
        showMessage('Please login to proceed with checkout', 'error');
        openLoginModal();
        return;
    }
    
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const shipping = total > 500 ? 0 : 50;
    
    const order = {
        id: Date.now(),
        userId: currentUser.id,
        items: [...cart],
        total: total + shipping,
        status: 'pending',
        createdAt: new Date().toISOString()
    };
    
    orders.push(order);
    localStorage.setItem('orders', JSON.stringify(orders));
    
    // Clear cart
    cart = [];
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartDisplay();
    
    showMessage('Order placed successfully!', 'success');
    
    // Redirect to order confirmation
    setTimeout(() => {
        window.location.href = 'pages/order-confirmation.html?id=' + order.id;
    }, 2000);
}

// Professional UX Functions
function showLoading(container = null) {
    const loadingDiv = document.createElement('div');
    loadingDiv.className = 'loading-overlay';
    loadingDiv.innerHTML = `
        <div class="loading-content">
            <div class="loading"></div>
            <div class="loading-text">Loading...</div>
        </div>
    `;
    
    if (container) {
        container.appendChild(loadingDiv);
    } else {
        document.body.appendChild(loadingDiv);
    }
    
    return loadingDiv;
}

function hideLoading(loadingDiv = null) {
    if (loadingDiv) {
        loadingDiv.remove();
    } else {
        const loading = document.querySelector('.loading-overlay');
        if (loading) loading.remove();
    }
}

function showMessage(message, type = 'success') {
    // Remove existing messages
    const existingMessages = document.querySelectorAll('.message');
    existingMessages.forEach(msg => msg.remove());
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    messageDiv.textContent = message;
    
    document.body.appendChild(messageDiv);
    
    // Auto remove after 4 seconds with slide out animation
    setTimeout(() => {
        messageDiv.style.animation = 'slideOut 0.3s ease forwards';
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.remove();
            }
        }, 300);
    }, 4000);
}

// Enhanced add to cart with loading state
function addToCartWithLoading(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    const addButton = event.target;
    const originalText = addButton.textContent;
    
    // Show loading state
    addButton.innerHTML = '<div class="loading"></div> Adding...';
    addButton.disabled = true;
    
    // Simulate loading time for better UX
    setTimeout(() => {
        const existingItem = cart.find(item => item.id === productId);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({
                id: product.id,
                name: product.name,
                price: product.price,
                image: product.image,
                quantity: 1
            });
        }
        
        localStorage.setItem('cart', JSON.stringify(cart));
        updateCartDisplay();
        
        // Show success state
        addButton.innerHTML = '✓ Added!';
        addButton.style.background = '#28a745';
        
        setTimeout(() => {
            addButton.innerHTML = originalText;
            addButton.style.background = '';
            addButton.disabled = false;
        }, 1500);
        
        showMessage('Product added to cart!', 'success');
    }, 800);
}

function formatPrice(price) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR'
    }).format(price);
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Admin functions
function loadAdminDashboard() {
    if (!currentUser || currentUser.role !== 'admin') {
        window.location.href = 'index.html';
        return;
    }
    
    const totalProducts = products.length;
    const totalOrders = orders.length;
    const totalUsers = JSON.parse(localStorage.getItem('users') || '[]').length;
    const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);
    
    document.getElementById('totalProducts').textContent = totalProducts;
    document.getElementById('totalOrders').textContent = totalOrders;
    document.getElementById('totalUsers').textContent = totalUsers;
    document.getElementById('totalRevenue').textContent = formatPrice(totalRevenue);
    
    loadRecentOrders();
    loadProductManagement();
}

function loadRecentOrders() {
    const recentOrders = orders.slice(-5).reverse();
    const ordersTable = document.querySelector('#recentOrdersTable');
    
    if (ordersTable) {
        ordersTable.innerHTML = recentOrders.map(order => `
            <tr>
                <td>#${order.id}</td>
                <td>${order.items.length} items</td>
                <td>${formatPrice(order.total)}</td>
                <td><span class="status status-${order.status}">${order.status}</span></td>
                <td>${formatDate(order.createdAt)}</td>
            </tr>
        `).join('');
    }
}

function loadProductManagement() {
    const productTable = document.querySelector('#productTable');
    
    if (productTable) {
        productTable.innerHTML = products.map(product => `
            <tr>
                <td><img src="${product.image}" alt="${product.name}" style="width: 50px; height: 50px; object-fit: cover;"></td>
                <td>${product.name}</td>
                <td>₹${product.price}</td>
                <td>${product.stock}</td>
                <td>${product.category}</td>
                <td>
                    <button class="btn btn-outline" onclick="editProduct(${product.id})">Edit</button>
                    <button class="btn btn-outline" onclick="deleteProduct(${product.id})">Delete</button>
                </td>
            </tr>
        `).join('');
    }
}

function addProduct() {
    const name = document.getElementById('productName').value;
    const price = parseFloat(document.getElementById('productPrice').value);
    const category = document.getElementById('productCategory').value;
    const description = document.getElementById('productDescription').value;
    const stock = parseInt(document.getElementById('productStock').value);
    const image = document.getElementById('productImage').value || 'images/placeholder.jpg';
    
    const newProduct = {
        id: Date.now(),
        name,
        price,
        category,
        description,
        stock,
        image,
        rating: 0,
        reviews: 0
    };
    
    products.push(newProduct);
    localStorage.setItem('products', JSON.stringify(products));
    
    loadProductManagement();
    showMessage('Product added successfully!', 'success');
    
    // Clear form
    document.getElementById('productForm').reset();
}

function editProduct(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    document.getElementById('productName').value = product.name;
    document.getElementById('productPrice').value = product.price;
    document.getElementById('productCategory').value = product.category;
    document.getElementById('productDescription').value = product.description;
    document.getElementById('productStock').value = product.stock;
    document.getElementById('productImage').value = product.image;
    
    // Change form to edit mode
    const form = document.getElementById('productForm');
    form.dataset.editId = productId;
    form.querySelector('button[type="submit"]').textContent = 'Update Product';
}

function deleteProduct(productId) {
    if (confirm('Are you sure you want to delete this product?')) {
        products = products.filter(p => p.id !== productId);
        localStorage.setItem('products', JSON.stringify(products));
        loadProductManagement();
        showMessage('Product deleted successfully!', 'success');
    }
}

function updateProduct(e) {
    e.preventDefault();
    
    const editId = document.getElementById('productForm').dataset.editId;
    if (!editId) {
        addProduct();
        return;
    }
    
    const productIndex = products.findIndex(p => p.id === parseInt(editId));
    if (productIndex === -1) return;
    
    products[productIndex] = {
        ...products[productIndex],
        name: document.getElementById('productName').value,
        price: parseFloat(document.getElementById('productPrice').value),
        category: document.getElementById('productCategory').value,
        description: document.getElementById('productDescription').value,
        stock: parseInt(document.getElementById('productStock').value),
        image: document.getElementById('productImage').value || 'images/placeholder.jpg'
    };
    
    localStorage.setItem('products', JSON.stringify(products));
    loadProductManagement();
    showMessage('Product updated successfully!', 'success');
    
    // Reset form
    document.getElementById('productForm').reset();
    document.getElementById('productForm').removeAttribute('data-edit-id');
    document.getElementById('productForm').querySelector('button[type="submit"]').textContent = 'Add Product';
}

// Reseller functions
function loadResellerDashboard() {
    if (!currentUser || currentUser.role !== 'reseller') {
        window.location.href = 'index.html';
        return;
    }
    
    const resellerOrders = orders.filter(order => order.userId === currentUser.id);
    const totalOrders = resellerOrders.length;
    const totalSpent = resellerOrders.reduce((sum, order) => sum + order.total, 0);
    
    document.getElementById('resellerTotalOrders').textContent = totalOrders;
    document.getElementById('resellerTotalSpent').textContent = formatPrice(totalSpent);
    
    loadResellerOrders();
    loadWholesaleProducts();
}

function loadResellerOrders() {
    const resellerOrders = orders.filter(order => order.userId === currentUser.id);
    const ordersTable = document.querySelector('#resellerOrdersTable');
    
    if (ordersTable) {
        ordersTable.innerHTML = resellerOrders.map(order => `
            <tr>
                <td>#${order.id}</td>
                <td>${order.items.length} items</td>
                <td>${formatPrice(order.total)}</td>
                <td><span class="status status-${order.status}">${order.status}</span></td>
                <td>${formatDate(order.createdAt)}</td>
            </tr>
        `).join('');
    }
}

function loadWholesaleProducts() {
    const wholesaleGrid = document.querySelector('#wholesaleProductsGrid');
    if (!wholesaleGrid) return;
    
    const wholesaleProducts = products.map(product => ({
        ...product,
        wholesalePrice: Math.round(product.price * 0.7), // 30% discount
        bulkDiscount: product.price > 1000 ? '25%' : '20%'
    }));
    
    wholesaleGrid.innerHTML = wholesaleProducts.map(product => `
        <div class="product-card">
            <div class="product-image">
                <img src="${product.image}" alt="${product.name}" onerror="this.src='/images/placeholder.jpg'">
                <div class="product-badge">Wholesale</div>
            </div>
            <div class="product-info">
                <h3 class="product-title"><a href="pages/product-detail.html?id=${product.id}" class="product-link">${product.name}</a></h3>
                <div class="product-price">
                    <span class="original-price">₹${product.price}</span>
                    <span class="wholesale-price">₹${product.wholesalePrice}</span>
                </div>
                <div class="discount-info">${product.bulkDiscount} off on bulk orders</div>
                <div class="product-actions">
                    <button class="add-to-cart" onclick="addToCartWithLoading(${product.id})">Add to Cart</button>
                    <button class="wishlist-btn" onclick="addToWishlist(${product.id})" title="Add to Wishlist">
                        <i class="fas fa-heart"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// Category page functions
function loadCategoryPage(category) {
    const categoryProducts = products.filter(product => product.category === category);
    const productsGrid = document.querySelector('.products-grid');
    
    if (!productsGrid) return;
    
    if (categoryProducts.length === 0) {
        productsGrid.innerHTML = '<p>No products found in this category.</p>';
        return;
    }
    
    productsGrid.innerHTML = categoryProducts.map(product => `
        <div class="product-card">
            <div class="product-image">
                <img src="${product.image}" alt="${product.name}" onerror="this.src='/images/placeholder.jpg'">
                ${product.rating >= 4.5 ? '<div class="product-badge">Best Seller</div>' : ''}
            </div>
            <div class="product-info">
                <h3 class="product-title"><a href="pages/product-detail.html?id=${product.id}" class="product-link">${product.name}</a></h3>
                <div class="product-price">₹${product.price}</div>
                <div class="product-rating">
                    <div class="stars">${generateStars(product.rating)}</div>
                    <span class="rating-text">(${product.reviews} reviews)</span>
                </div>
                <div class="product-actions">
                    <button class="add-to-cart" onclick="addToCartWithLoading(${product.id})">Add to Cart</button>
                    <button class="wishlist-btn" onclick="addToWishlist(${product.id})" title="Add to Wishlist">
                        <i class="fas fa-heart"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// Filter and sort functions
function sortProducts(category) {
    const sortBy = document.getElementById('sortBy').value;
    const products = JSON.parse(localStorage.getItem('products') || '[]');
    const categoryProducts = products.filter(product => product.category === category);
    let sortedProducts = [...categoryProducts];
    
    switch (sortBy) {
        case 'name':
            sortedProducts.sort((a, b) => a.name.localeCompare(b.name));
            break;
        case 'price-low':
            sortedProducts.sort((a, b) => a.price - b.price);
            break;
        case 'price-high':
            sortedProducts.sort((a, b) => b.price - a.price);
            break;
        case 'rating':
            sortedProducts.sort((a, b) => b.rating - a.rating);
            break;
    }
    
    displayProducts(sortedProducts, category);
}

function filterByPrice(category) {
    const priceRange = document.getElementById('priceRange').value;
    const products = JSON.parse(localStorage.getItem('products') || '[]');
    let categoryProducts = products.filter(product => product.category === category);
    
    if (priceRange !== 'all') {
        const [min, max] = priceRange.split('-').map(Number);
        if (priceRange.includes('+')) {
            categoryProducts = categoryProducts.filter(product => product.price >= min);
        } else {
            categoryProducts = categoryProducts.filter(product => product.price >= min && product.price <= max);
        }
    }
    
    displayProducts(categoryProducts, category);
}

function clearFilters(category) {
    document.getElementById('sortBy').value = 'name';
    document.getElementById('priceRange').value = 'all';
    loadCategoryPage(category);
}

function displayProducts(products, category) {
    const gridId = category + 'ProductsGrid';
    const productsGrid = document.getElementById(gridId);
    
    if (!productsGrid) return;
    
    if (products.length === 0) {
        productsGrid.innerHTML = '<p class="no-products">No products found matching your criteria.</p>';
        return;
    }
    
    productsGrid.innerHTML = products.map(product => `
        <div class="product-card">
            <div class="product-image">
                <img src="${product.image}" alt="${product.name}" onerror="this.src='/images/placeholder.jpg'">
                ${product.rating >= 4.5 ? '<div class="product-badge">Best Seller</div>' : ''}
            </div>
            <div class="product-info">
                <h3 class="product-title"><a href="pages/product-detail.html?id=${product.id}" class="product-link">${product.name}</a></h3>
                <div class="product-price">₹${product.price}</div>
                <div class="product-rating">
                    <div class="stars">${generateStars(product.rating)}</div>
                    <span class="rating-text">(${product.reviews} reviews)</span>
                </div>
                <div class="product-actions">
                    <button class="add-to-cart" onclick="addToCartWithLoading(${product.id})">Add to Cart</button>
                    <button class="wishlist-btn" onclick="addToWishlist(${product.id})" title="Add to Wishlist">
                        <i class="fas fa-heart"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

function filterByType(type) {
    // This function would filter products by specific types within categories
    // For now, we'll just show a message
    showMessage(`Filtering by ${type} type - Feature coming soon!`, 'success');
}

// Initialize default users
function initializeDefaultUsers() {
    const users = [
        {
            id: 1,
            name: 'Admin User',
            email: 'admin@nrtrader.com',
            password: 'admin123',
            role: 'admin',
            createdAt: new Date().toISOString()
        },
        {
            id: 2,
            name: 'Reseller User',
            email: 'reseller@nrtrader.com',
            password: 'reseller123',
            role: 'reseller',
            createdAt: new Date().toISOString()
        },
        {
            id: 3,
            name: 'Customer User',
            email: 'customer@nrtrader.com',
            password: 'customer123',
            role: 'user',
            createdAt: new Date().toISOString()
        }
    ];
    
    localStorage.setItem('users', JSON.stringify(users));
}

// Admin Dashboard Functions
function loadAdminDashboard() {
    if (!currentUser || currentUser.role !== 'admin') {
        window.location.href = '../index.html';
        return;
    }
    
    loadDashboardStats();
    loadRecentOrders();
    loadUsersTable();
    loadResellersTable();
    loadProductsTable();
    loadImageGallery();
    loadAdminOrders();
}

function loadDashboardStats() {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const orders = JSON.parse(localStorage.getItem('orders') || '[]');
    const products = JSON.parse(localStorage.getItem('products') || '[]');
    
    // Update stats
    const totalUsersEl = document.getElementById('totalUsers');
    const totalOrdersEl = document.getElementById('totalOrders');
    const totalProductsEl = document.getElementById('totalProducts');
    const totalResellersEl = document.getElementById('totalResellers');
    const totalRevenueEl = document.getElementById('totalRevenue');
    
    if (totalUsersEl) totalUsersEl.textContent = users.length;
    if (totalOrdersEl) totalOrdersEl.textContent = orders.length;
    if (totalProductsEl) totalProductsEl.textContent = products.length;
    if (totalResellersEl) totalResellersEl.textContent = users.filter(u => u.role === 'reseller').length;
    
    const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);
    if (totalRevenueEl) totalRevenueEl.textContent = `₹${totalRevenue}`;
}

function loadUsersTable() {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const orders = JSON.parse(localStorage.getItem('orders') || '[]');
    const tbody = document.getElementById('usersTableBody');
    
    if (!tbody) return;
    
    tbody.innerHTML = users.map(user => {
        const userOrders = orders.filter(order => order.userId === user.id);
        const totalSpent = userOrders.reduce((sum, order) => sum + order.total, 0);
        
        return `
            <tr>
                <td>${user.id}</td>
                <td>${user.name}</td>
                <td>${user.email}</td>
                <td><span class="role-badge role-${user.role}">${user.role}</span></td>
                <td>${userOrders.length}</td>
                <td>₹${totalSpent}</td>
                <td><span class="status-badge status-${user.status || 'active'}">${user.status || 'active'}</span></td>
                <td>
                    <button class="action-btn btn-edit" onclick="editUser(${user.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn btn-suspend" onclick="toggleUserStatus(${user.id})">
                        <i class="fas fa-ban"></i>
                    </button>
                    <button class="action-btn btn-delete" onclick="deleteUser(${user.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

function loadResellersTable() {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const resellers = users.filter(u => u.role === 'reseller');
    const orders = JSON.parse(localStorage.getItem('orders') || '[]');
    const tbody = document.getElementById('resellersTableBody');
    
    if (!tbody) return;
    
    // Update reseller stats
    const activeResellersEl = document.getElementById('activeResellers');
    const pendingResellersEl = document.getElementById('pendingResellers');
    
    const activeResellers = resellers.filter(r => r.status === 'active' || !r.status).length;
    const pendingResellers = resellers.filter(r => r.status === 'pending').length;
    
    if (activeResellersEl) activeResellersEl.textContent = activeResellers;
    if (pendingResellersEl) pendingResellersEl.textContent = pendingResellers;
    
    tbody.innerHTML = resellers.map(reseller => {
        const resellerOrders = orders.filter(order => order.userId === reseller.id);
        const totalSales = resellerOrders.reduce((sum, order) => sum + order.total, 0);
        
        return `
            <tr>
                <td>${reseller.id}</td>
                <td>${reseller.businessName || reseller.name}</td>
                <td>${reseller.name}</td>
                <td>${reseller.email}</td>
                <td>${reseller.phone || 'N/A'}</td>
                <td>${reseller.commission || 10}%</td>
                <td>₹${totalSales}</td>
                <td><span class="status-badge status-${reseller.status || 'active'}">${reseller.status || 'active'}</span></td>
                <td>
                    <button class="action-btn btn-edit" onclick="editReseller(${reseller.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn btn-suspend" onclick="toggleResellerStatus(${reseller.id})">
                        <i class="fas fa-ban"></i>
                    </button>
                    <button class="action-btn btn-delete" onclick="deleteReseller(${reseller.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

function loadRecentOrders() {
    const orders = JSON.parse(localStorage.getItem('orders') || '[]');
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const tbody = document.querySelector('#recentOrdersTable tbody');
    
    if (!tbody) return;
    
    const recentOrders = orders.slice(-10).reverse(); // Last 10 orders, newest first
    
    tbody.innerHTML = recentOrders.map(order => {
        const user = users.find(u => u.id === order.userId);
        const itemCount = order.items ? order.items.length : 0;
        
        return `
            <tr>
                <td>#${order.id}</td>
                <td>${itemCount} item(s)</td>
                <td>₹${order.total}</td>
                <td><span class="status-badge status-${order.status}">${order.status}</span></td>
                <td>${new Date(order.date).toLocaleDateString()}</td>
            </tr>
        `;
    }).join('');
}

// Modal functions
function openAddUserModal() {
    const modal = document.getElementById('addUserModal');
    if (modal) modal.style.display = 'block';
}

function openAddResellerModal() {
    const modal = document.getElementById('addResellerModal');
    if (modal) modal.style.display = 'block';
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.style.display = 'none';
}

function addUser(event) {
    event.preventDefault();
    
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const newUser = {
        id: Date.now(),
        name: document.getElementById('userName').value,
        email: document.getElementById('userEmail').value,
        password: document.getElementById('userPassword').value,
        role: document.getElementById('userRole').value,
        phone: document.getElementById('userPhone').value,
        status: 'active',
        createdAt: new Date().toISOString()
    };
    
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    
    showMessage('User added successfully!', 'success');
    closeModal('addUserModal');
    document.getElementById('addUserForm').reset();
    loadUsersTable();
    loadDashboardStats();
}

function addReseller(event) {
    event.preventDefault();
    
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const newReseller = {
        id: Date.now(),
        name: document.getElementById('resellerContactPerson').value,
        email: document.getElementById('resellerEmail').value,
        password: document.getElementById('resellerPassword').value,
        role: 'reseller',
        businessName: document.getElementById('resellerBusinessName').value,
        phone: document.getElementById('resellerPhone').value,
        address: document.getElementById('resellerAddress').value,
        commission: parseFloat(document.getElementById('resellerCommission').value),
        status: 'active',
        createdAt: new Date().toISOString()
    };
    
    users.push(newReseller);
    localStorage.setItem('users', JSON.stringify(users));
    
    showMessage('Reseller added successfully!', 'success');
    closeModal('addResellerModal');
    document.getElementById('addResellerForm').reset();
    loadResellersTable();
    loadDashboardStats();
}

function editUser(userId) {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(u => u.id === userId);
    
    if (!user) return;
    
    document.getElementById('editUserId').value = user.id;
    document.getElementById('editUserName').value = user.name;
    document.getElementById('editUserEmail').value = user.email;
    document.getElementById('editUserRole').value = user.role;
    document.getElementById('editUserStatus').value = user.status || 'active';
    
    document.getElementById('editUserModal').style.display = 'block';
}

function updateUser(event) {
    event.preventDefault();
    
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const userId = parseInt(document.getElementById('editUserId').value);
    const userIndex = users.findIndex(u => u.id === userId);
    
    if (userIndex === -1) return;
    
    users[userIndex].name = document.getElementById('editUserName').value;
    users[userIndex].email = document.getElementById('editUserEmail').value;
    users[userIndex].role = document.getElementById('editUserRole').value;
    users[userIndex].status = document.getElementById('editUserStatus').value;
    
    localStorage.setItem('users', JSON.stringify(users));
    
    showMessage('User updated successfully!', 'success');
    closeModal('editUserModal');
    loadUsersTable();
    loadResellersTable();
    loadDashboardStats();
}

function deleteUser(userId) {
    if (!confirm('Are you sure you want to delete this user?')) return;
    
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const filteredUsers = users.filter(u => u.id !== userId);
    
    localStorage.setItem('users', JSON.stringify(filteredUsers));
    
    showMessage('User deleted successfully!', 'success');
    loadUsersTable();
    loadResellersTable();
    loadDashboardStats();
}

function toggleUserStatus(userId) {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const userIndex = users.findIndex(u => u.id === userId);
    
    if (userIndex === -1) return;
    
    const currentStatus = users[userIndex].status || 'active';
    users[userIndex].status = currentStatus === 'active' ? 'suspended' : 'active';
    
    localStorage.setItem('users', JSON.stringify(users));
    
    showMessage(`User ${users[userIndex].status} successfully!`, 'success');
    loadUsersTable();
    loadResellersTable();
}

function filterUsers() {
    const filter = document.getElementById('userRoleFilter').value;
    const rows = document.querySelectorAll('#usersTableBody tr');
    
    rows.forEach(row => {
        const roleCell = row.cells[3];
        const role = roleCell.querySelector('.role-badge').textContent.toLowerCase();
        
        if (filter === 'all' || role === filter) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// Enhanced Admin Functions
function loadProductsTable() {
    const products = JSON.parse(localStorage.getItem('products') || '[]');
    const tbody = document.getElementById('productsTableBody');
    
    if (!tbody) return;
    
    tbody.innerHTML = products.map(product => `
        <tr>
            <td>${product.id}</td>
            <td>
                <img src="${product.image}" alt="${product.name}" class="product-thumb" 
                     style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">
            </td>
            <td>${product.name}</td>
            <td><span class="category-badge category-${product.category}">${product.category}</span></td>
            <td>₹${product.price}</td>
            <td>${product.stock || 0}</td>
            <td><span class="status-badge status-${product.status || 'active'}">${product.status || 'active'}</span></td>
            <td>
                <button class="action-btn btn-edit" onclick="editProduct(${product.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="action-btn btn-delete" onclick="deleteProduct(${product.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

function loadImageGallery() {
    const images = JSON.parse(localStorage.getItem('uploadedImages') || '[]');
    const container = document.getElementById('imageGallery');
    
    if (!container) return;
    
    if (images.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-images"></i>
                <h3>No Images Uploaded</h3>
                <p>Upload images to manage your product gallery.</p>
            </div>
        `;
    } else {
        container.innerHTML = images.map(image => `
            <div class="image-item">
                <img src="${image.url}" alt="${image.name}">
                <div class="image-actions-overlay">
                    <button class="image-action-btn" onclick="copyImageUrl('${image.url}')" title="Copy URL">
                        <i class="fas fa-copy"></i>
                    </button>
                    <button class="image-action-btn" onclick="deleteImage('${image.id}')" title="Delete">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
                <div class="image-filename">${image.name}</div>
            </div>
        `).join('');
    }
}

function uploadImages() {
    const input = document.getElementById('imageUpload');
    const files = input.files;
    
    if (files.length === 0) return;
    
    const images = JSON.parse(localStorage.getItem('uploadedImages') || '[]');
    
    Array.from(files).forEach(file => {
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const newImage = {
                    id: Date.now() + Math.random(),
                    name: file.name,
                    url: e.target.result,
                    size: file.size,
                    uploadedAt: new Date().toISOString()
                };
                
                images.push(newImage);
                localStorage.setItem('uploadedImages', JSON.stringify(images));
                
                showMessage(`Image "${file.name}" uploaded successfully!`, 'success');
                loadImageGallery();
            };
            reader.readAsDataURL(file);
        }
    });
    
    input.value = '';
}

function copyImageUrl(url) {
    navigator.clipboard.writeText(url).then(() => {
        showMessage('Image URL copied to clipboard!', 'success');
    });
}

function deleteImage(imageId) {
    if (!confirm('Are you sure you want to delete this image?')) return;
    
    const images = JSON.parse(localStorage.getItem('uploadedImages') || '[]');
    const filteredImages = images.filter(img => img.id !== imageId);
    
    localStorage.setItem('uploadedImages', JSON.stringify(filteredImages));
    showMessage('Image deleted successfully!', 'success');
    loadImageGallery();
}

function refreshImageGallery() {
    loadImageGallery();
    showMessage('Image gallery refreshed!', 'success');
}

function loadAdminOrders() {
    const orders = JSON.parse(localStorage.getItem('orders') || '[]');
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const tbody = document.getElementById('adminOrdersTableBody');
    
    if (!tbody) return;
    
    tbody.innerHTML = orders.map(order => {
        const user = users.find(u => u.id === order.userId);
        const itemCount = order.items ? order.items.length : 0;
        
        return `
            <tr>
                <td>#${order.id}</td>
                <td>${user ? user.name : 'Unknown User'}</td>
                <td>${itemCount} item(s)</td>
                <td>₹${order.total}</td>
                <td>
                    <select class="status-select" onchange="updateOrderStatus(${order.id}, this.value)">
                        <option value="pending" ${order.status === 'pending' ? 'selected' : ''}>Pending</option>
                        <option value="processing" ${order.status === 'processing' ? 'selected' : ''}>Processing</option>
                        <option value="shipped" ${order.status === 'shipped' ? 'selected' : ''}>Shipped</option>
                        <option value="delivered" ${order.status === 'delivered' ? 'selected' : ''}>Delivered</option>
                        <option value="cancelled" ${order.status === 'cancelled' ? 'selected' : ''}>Cancelled</option>
                    </select>
                </td>
                <td>${new Date(order.date).toLocaleDateString()}</td>
                <td>
                    <button class="action-btn btn-edit" onclick="viewOrderDetails(${order.id})">
                        <i class="fas fa-eye"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

function updateOrderStatus(orderId, newStatus) {
    const orders = JSON.parse(localStorage.getItem('orders') || '[]');
    const orderIndex = orders.findIndex(o => o.id === orderId);
    
    if (orderIndex !== -1) {
        orders[orderIndex].status = newStatus;
        orders[orderIndex].statusUpdatedAt = new Date().toISOString();
        
        localStorage.setItem('orders', JSON.stringify(orders));
        showMessage(`Order #${orderId} status updated to ${newStatus}!`, 'success');
    }
}

function filterAdminOrders() {
    const filter = document.getElementById('adminOrderFilter').value;
    const rows = document.querySelectorAll('#adminOrdersTableBody tr');
    
    rows.forEach(row => {
        const statusSelect = row.querySelector('.status-select');
        const status = statusSelect ? statusSelect.value : '';
        
        if (filter === 'all' || status === filter) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

function viewOrderDetails(orderId) {
    const orders = JSON.parse(localStorage.getItem('orders') || '[]');
    const order = orders.find(o => o.id === orderId);
    
    if (!order) return;
    
    const orderDetails = `
        Order ID: #${order.id}
        Date: ${new Date(order.date).toLocaleDateString()}
        Status: ${order.status}
        Total: ₹${order.total}
        
        Items:
        ${order.items.map(item => `- ${item.name} (Qty: ${item.quantity}) - ₹${item.price}`).join('\n')}
    `;
    
    alert(orderDetails);
}

// Wishlist Functions
function addToWishlist(productId) {
    if (!currentUser) {
        showMessage('Please login to add items to wishlist', 'error');
        openLoginModal();
        return;
    }
    
    let wishlist = JSON.parse(localStorage.getItem('wishlist') || '[]');
    
    if (!wishlist.includes(productId)) {
        wishlist.push(productId);
        localStorage.setItem('wishlist', JSON.stringify(wishlist));
        showMessage('Item added to wishlist!', 'success');
    } else {
        showMessage('Item already in wishlist!', 'error');
    }
}

function removeFromWishlist(productId) {
    let wishlist = JSON.parse(localStorage.getItem('wishlist') || '[]');
    wishlist = wishlist.filter(id => id !== productId);
    localStorage.setItem('wishlist', JSON.stringify(wishlist));
    
    showMessage('Item removed from wishlist', 'success');
    
    // Update wishlist display if on wishlist page
    if (typeof loadUserWishlist === 'function') {
        loadUserWishlist();
    }
}

// Enhanced Product Management Functions
function openAddProductModal() {
    document.getElementById('productModalTitle').textContent = 'Add New Product';
    document.getElementById('productModalSubmitBtn').textContent = 'Add Product';
    document.getElementById('productId').value = '';
    document.getElementById('productModalForm').reset();
    loadImageSelectionGrid();
    document.getElementById('addProductModal').style.display = 'block';
}

function openEditProductModal(productId) {
    const products = JSON.parse(localStorage.getItem('products') || '[]');
    const product = products.find(p => p.id === productId);
    
    if (!product) return;
    
    document.getElementById('productModalTitle').textContent = 'Edit Product';
    document.getElementById('productModalSubmitBtn').textContent = 'Update Product';
    document.getElementById('productId').value = product.id;
    
    // Fill form with product data
    document.getElementById('modalProductName').value = product.name || '';
    document.getElementById('modalProductPrice').value = product.price || '';
    document.getElementById('modalProductCategory').value = product.category || '';
    document.getElementById('modalProductStock').value = product.stock || 0;
    document.getElementById('modalProductStatus').value = product.status || 'active';
    document.getElementById('modalProductWeight').value = product.weight || '';
    document.getElementById('modalProductDescription').value = product.description || '';
    document.getElementById('modalProductFeatures').value = product.features ? product.features.join('\n') : '';
    document.getElementById('modalProductImage').value = product.image || '';
    document.getElementById('modalProductImageAlt').value = product.imageAlt || '';
    document.getElementById('modalProductSKU').value = product.sku || '';
    document.getElementById('modalProductBarcode').value = product.barcode || '';
    
    loadImageSelectionGrid();
    document.getElementById('addProductModal').style.display = 'block';
}

function loadImageSelectionGrid() {
    const images = JSON.parse(localStorage.getItem('uploadedImages') || '[]');
    const container = document.getElementById('imageSelectionGrid');
    
    if (!container) return;
    
    if (images.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="grid-column: 1 / -1; text-align: center; padding: 2rem;">
                <i class="fas fa-images" style="font-size: 2rem; color: #ddd; margin-bottom: 1rem;"></i>
                <p style="color: #666;">No images uploaded yet. Upload images first.</p>
            </div>
        `;
    } else {
        container.innerHTML = images.map(image => `
            <div class="image-selection-item" onclick="selectImage('${image.url}')">
                <img src="${image.url}" alt="${image.name}">
                <div class="select-overlay">
                    <i class="fas fa-check"></i>
                </div>
            </div>
        `).join('');
    }
}

function selectImage(imageUrl) {
    // Remove previous selection
    document.querySelectorAll('.image-selection-item').forEach(item => {
        item.classList.remove('selected');
    });
    
    // Add selection to clicked item
    event.currentTarget.classList.add('selected');
    
    // Set the image URL in the form
    document.getElementById('modalProductImage').value = imageUrl;
}

function saveProduct(event) {
    event.preventDefault();
    
    const products = JSON.parse(localStorage.getItem('products') || '[]');
    const productId = document.getElementById('productId').value;
    const isEditing = !!productId;
    
    const productData = {
        id: isEditing ? parseInt(productId) : Date.now(),
        name: document.getElementById('modalProductName').value,
        price: parseFloat(document.getElementById('modalProductPrice').value),
        category: document.getElementById('modalProductCategory').value,
        stock: parseInt(document.getElementById('modalProductStock').value),
        status: document.getElementById('modalProductStatus').value,
        weight: document.getElementById('modalProductWeight').value || null,
        description: document.getElementById('modalProductDescription').value,
        features: document.getElementById('modalProductFeatures').value.split('\n').filter(f => f.trim()),
        image: document.getElementById('modalProductImage').value || '../images/placeholder.jpg',
        imageAlt: document.getElementById('modalProductImageAlt').value || '',
        sku: document.getElementById('modalProductSKU').value || generateSKU(),
        barcode: document.getElementById('modalProductBarcode').value || '',
        createdAt: isEditing ? products.find(p => p.id === parseInt(productId))?.createdAt || new Date().toISOString() : new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    
    if (isEditing) {
        const index = products.findIndex(p => p.id === parseInt(productId));
        if (index !== -1) {
            products[index] = productData;
        }
    } else {
        products.push(productData);
    }
    
    localStorage.setItem('products', JSON.stringify(products));
    
    showMessage(isEditing ? 'Product updated successfully!' : 'Product added successfully!', 'success');
    closeModal('addProductModal');
    loadProductsTable();
    loadDashboardStats();
}

function generateSKU() {
    const timestamp = Date.now().toString().slice(-6);
    const random = Math.random().toString(36).substr(2, 3).toUpperCase();
    return `SKU-${timestamp}-${random}`;
}

function filterProducts() {
    const categoryFilter = document.getElementById('productCategoryFilter').value;
    const statusFilter = document.getElementById('productStatusFilter').value;
    const searchTerm = document.getElementById('productSearch').value.toLowerCase();
    
    const products = JSON.parse(localStorage.getItem('products') || '[]');
    let filteredProducts = products;
    
    // Filter by category
    if (categoryFilter !== 'all') {
        filteredProducts = filteredProducts.filter(p => p.category === categoryFilter);
    }
    
    // Filter by status
    if (statusFilter !== 'all') {
        if (statusFilter === 'out-of-stock') {
            filteredProducts = filteredProducts.filter(p => p.stock === 0);
        } else {
            filteredProducts = filteredProducts.filter(p => p.status === statusFilter);
        }
    }
    
    // Filter by search term
    if (searchTerm) {
        filteredProducts = filteredProducts.filter(p => 
            p.name.toLowerCase().includes(searchTerm) ||
            p.description.toLowerCase().includes(searchTerm) ||
            p.sku.toLowerCase().includes(searchTerm)
        );
    }
    
    // Update the table
    const tbody = document.getElementById('productsTableBody');
    if (tbody) {
        tbody.innerHTML = filteredProducts.map(product => `
            <tr>
                <td>${product.id}</td>
                <td>
                    <img src="${product.image}" alt="${product.name}" class="product-thumb" 
                         style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">
                </td>
                <td>${product.name}</td>
                <td><span class="category-badge category-${product.category}">${product.category}</span></td>
                <td>₹${product.price}</td>
                <td>${product.stock}</td>
                <td><span class="status-badge status-${product.status || 'active'}">${product.status || 'active'}</span></td>
                <td>
                    <button class="action-btn btn-edit" onclick="openEditProductModal(${product.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn btn-delete" onclick="deleteProduct(${product.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    }
}

function searchProducts() {
    filterProducts(); // Reuse the filter function
}

function clearProductFilters() {
    document.getElementById('productCategoryFilter').value = 'all';
    document.getElementById('productStatusFilter').value = 'all';
    document.getElementById('productSearch').value = '';
    filterProducts();
}

function exportProducts() {
    const products = JSON.parse(localStorage.getItem('products') || '[]');
    
    if (products.length === 0) {
        showMessage('No products to export', 'error');
        return;
    }
    
    // Convert to CSV
    const headers = ['ID', 'Name', 'Category', 'Price', 'Stock', 'Status', 'SKU', 'Description'];
    const csvContent = [
        headers.join(','),
        ...products.map(product => [
            product.id,
            `"${product.name}"`,
            product.category,
            product.price,
            product.stock,
            product.status || 'active',
            product.sku || '',
            `"${product.description.replace(/"/g, '""')}"`
        ].join(','))
    ].join('\n');
    
    // Create and download file
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `products_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    showMessage('Products exported successfully!', 'success');
}

function deleteProduct(productId) {
    if (!confirm('Are you sure you want to delete this product?')) return;
    
    const products = JSON.parse(localStorage.getItem('products') || '[]');
    const filteredProducts = products.filter(p => p.id !== productId);
    
    localStorage.setItem('products', JSON.stringify(filteredProducts));
    
    showMessage('Product deleted successfully!', 'success');
    loadProductsTable();
    loadDashboardStats();
}

// Export functions for use in other pages
window.addToCart = addToCart;
window.removeFromCart = removeFromCart;
window.updateCartQuantity = updateCartQuantity;
window.loadCartPage = loadCartPage;
window.checkout = checkout;
window.logout = logout;
window.openLoginModal = openLoginModal;
window.openRegisterModal = openRegisterModal;
window.closeLoginModal = closeLoginModal;
window.closeRegisterModal = closeRegisterModal;
window.loadCategoryPage = loadCategoryPage;
window.loadAdminDashboard = loadAdminDashboard;
window.loadResellerDashboard = loadResellerDashboard;

// Admin Management Functions
window.loadDashboardStats = loadDashboardStats;
window.loadUsersTable = loadUsersTable;
window.loadResellersTable = loadResellersTable;
window.loadRecentOrders = loadRecentOrders;
window.openAddUserModal = openAddUserModal;
window.openAddResellerModal = openAddResellerModal;
window.closeModal = closeModal;
window.addUser = addUser;
window.addReseller = addReseller;
window.editUser = editUser;
window.updateUser = updateUser;
window.deleteUser = deleteUser;
window.toggleUserStatus = toggleUserStatus;
window.filterUsers = filterUsers;

// Enhanced Admin Functions
window.loadProductsTable = loadProductsTable;
window.loadImageGallery = loadImageGallery;
window.uploadImages = uploadImages;
window.copyImageUrl = copyImageUrl;
window.deleteImage = deleteImage;
window.refreshImageGallery = refreshImageGallery;
window.loadAdminOrders = loadAdminOrders;
window.updateOrderStatus = updateOrderStatus;
window.filterAdminOrders = filterAdminOrders;
window.viewOrderDetails = viewOrderDetails;

// Wishlist Functions
window.addToWishlist = addToWishlist;
window.removeFromWishlist = removeFromWishlist;

// Enhanced Product Management Functions
window.openAddProductModal = openAddProductModal;
window.openEditProductModal = openEditProductModal;
window.saveProduct = saveProduct;
window.selectImage = selectImage;
window.filterProducts = filterProducts;
window.searchProducts = searchProducts;
window.clearProductFilters = clearProductFilters;
window.exportProducts = exportProducts;
window.generateSKU = generateSKU;

window.addProduct = addProduct;
window.editProduct = editProduct;
window.deleteProduct = deleteProduct;
window.updateProduct = updateProduct;
window.sortProducts = sortProducts;
window.filterByPrice = filterByPrice;
window.clearFilters = clearFilters;
window.filterByType = filterByType;
